// ============================================
//  StockAI Dashboard — app.js
// ============================================

// ── Stock data ───────────────────────────────
const STOCKS = {
  AAPL: {
    price: 189.42, pred: 192.10, acc: 79.4, rmse: 3.42,
    signal: 'STRONG BUY', conf: 82, color: '#378ADD',
    news: 74, twit: 68, reddit: 45, analyst: 86,
    rsi: 58.3, macd: '+0.82', sma20: 185.2, sma50: 181.4,
    bb: 'Mid Band', obv: 'Rising', atr: 2.14,
    newsItems: [
      'Apple reports record Q1 earnings, beats estimates by 8%',
      'Fed signals rate pause, tech stocks rally',
      'AAPL iPhone 17 pre-orders exceed analyst expectations',
      'Market volatility index (VIX) drops to 3-month low',
      'Apple Vision Pro 2 rumored for Q3 launch'
    ]
  },
  GOOGL: {
    price: 172.18, pred: 175.50, acc: 77.2, rmse: 4.11,
    signal: 'BUY', conf: 76, color: '#D85A30',
    news: 68, twit: 72, reddit: 55, analyst: 79,
    rsi: 62.1, macd: '+1.21', sma20: 169.4, sma50: 163.8,
    bb: 'Upper Band', obv: 'Rising', atr: 3.02,
    newsItems: [
      'Google Cloud revenue surges 28% YoY',
      'Gemini AI beats GPT-4 on coding benchmarks',
      'Alphabet buyback program expanded to $70B',
      'Regulatory headwinds ease for Google Search',
      'YouTube Shorts monetization exceeds expectations'
    ]
  },
  MSFT: {
    price: 415.32, pred: 421.80, acc: 80.1, rmse: 5.23,
    signal: 'STRONG BUY', conf: 85, color: '#639922',
    news: 81, twit: 75, reddit: 61, analyst: 91,
    rsi: 55.7, macd: '+2.14', sma20: 409.1, sma50: 398.6,
    bb: 'Mid Band', obv: 'Rising', atr: 4.51,
    newsItems: [
      'Microsoft Copilot adoption hits 50M users',
      'Azure growth accelerates to 32% in latest quarter',
      'Microsoft-OpenAI partnership extended through 2030',
      'Teams premium hits record enterprise adoption',
      'Microsoft gaming revenue up 51% post-Activision'
    ]
  },
  TSLA: {
    price: 248.75, pred: 241.20, acc: 71.8, rmse: 8.27,
    signal: 'HOLD', conf: 59, color: '#EF9F27',
    news: 42, twit: 58, reddit: 71, analyst: 52,
    rsi: 44.2, macd: '-1.87', sma20: 255.4, sma50: 262.1,
    bb: 'Lower Band', obv: 'Falling', atr: 9.34,
    newsItems: [
      'Tesla Cybertruck recall affects 46k vehicles',
      'Elon Musk sells $2B in TSLA shares',
      'Tesla FSD v13 shows 40% fewer interventions',
      'Price cuts in China impact gross margin',
      'Tesla Energy Megapack revenue hits record'
    ]
  },
  AMZN: {
    price: 198.45, pred: 204.30, acc: 78.6, rmse: 4.88,
    signal: 'BUY', conf: 78, color: '#BA7517',
    news: 76, twit: 69, reddit: 53, analyst: 88,
    rsi: 60.4, macd: '+1.55', sma20: 193.2, sma50: 186.7,
    bb: 'Mid Band', obv: 'Rising', atr: 3.77,
    newsItems: [
      'AWS revenue crosses $100B annual run rate',
      'Amazon Prime membership hits 230M globally',
      'Delivery drone service expands to 10 new cities',
      'Amazon advertising business grows 24% YoY',
      'AWS AI services drive record enterprise deals'
    ]
  },
  NVDA: {
    price: 875.40, pred: 912.00, acc: 82.3, rmse: 12.4,
    signal: 'STRONG BUY', conf: 88, color: '#7F77DD',
    news: 89, twit: 83, reddit: 78, analyst: 94,
    rsi: 71.2, macd: '+8.43', sma20: 841.3, sma50: 795.6,
    bb: 'Upper Band', obv: 'Surging', atr: 18.2,
    newsItems: [
      'NVIDIA H200 demand exceeds supply by 300%',
      'Blackwell GPU architecture ships to hyperscalers',
      'NVDA joins Dow Jones Industrial Average',
      'Jensen Huang forecasts $1T AI infrastructure spend',
      'NVIDIA gaming GPU market share hits 88%'
    ]
  }
};

// ── State ─────────────────────────────────────
let currentTicker = 'AAPL';
let priceChartInst, sentChartInst, shapChartInst, lossChartInst, horizonChartInst;
const priceData = {};

// ── Helpers ───────────────────────────────────
function genPriceSeries(base, n, vol) {
  let arr = [base], p = base;
  for (let i = 1; i < n; i++) {
    p += (Math.random() - 0.48) * vol;
    arr.push(Math.max(p, base * 0.7));
  }
  return arr;
}

function genPredSeries(actual, offset, noise) {
  return actual.map((v, i) =>
    i < actual.length - 5
      ? v + offset * (Math.random() * 0.6 + 0.7) + (Math.random() - 0.5) * noise
      : null
  );
}

function buildPriceData(ticker) {
  const s = STOCKS[ticker];
  const n = 90, vol = s.price * 0.012;
  const actual = genPriceSeries(s.price * 0.85, n, vol);
  actual[n - 1] = s.price;
  const pred  = genPredSeries(actual, s.pred - s.price, vol * 0.5);
  const upper = actual.map((v, i) => pred[i] !== null ? pred[i] + vol * 1.5 * (1 + i * 0.02) : null);
  const lower = actual.map((v, i) => pred[i] !== null ? pred[i] - vol * 1.5 * (1 + i * 0.02) : null);
  const labels = [];
  for (let i = n - 1; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    labels.push(d.toLocaleDateString('en', { month: 'short', day: 'numeric' }));
  }
  return { actual, pred, upper, lower, labels };
}

// ── Chart initialisers ────────────────────────
function initPriceChart(ticker) {
  const d = buildPriceData(ticker);
  priceData[ticker] = d;
  const ctx = document.getElementById('priceChart').getContext('2d');
  if (priceChartInst) priceChartInst.destroy();
  priceChartInst = new Chart(ctx, {
    type: 'line',
    data: {
      labels: d.labels,
      datasets: [
        { label: 'Confidence High', data: d.upper, borderColor: 'transparent', backgroundColor: 'rgba(55,138,221,0.1)', fill: '+1', pointRadius: 0, tension: 0.4 },
        { label: 'Confidence Low',  data: d.lower, borderColor: 'transparent', backgroundColor: 'rgba(55,138,221,0.1)', fill: false, pointRadius: 0, tension: 0.4 },
        { label: 'Actual',    data: d.actual, borderColor: '#378ADD', backgroundColor: 'transparent', borderWidth: 2, pointRadius: 0, tension: 0.4 },
        { label: 'Predicted', data: d.pred,   borderColor: '#D85A30', backgroundColor: 'transparent', borderWidth: 2, borderDash: [5, 3], pointRadius: 0, tension: 0.4 }
      ]
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: { mode: 'index', intersect: false, callbacks: { label: c => `${c.dataset.label}: $${c.parsed.y ? c.parsed.y.toFixed(2) : ''}` } }
      },
      scales: {
        x: { grid: { color: 'rgba(128,128,128,.08)' }, ticks: { maxTicksLimit: 8, color: '#888', font: { size: 10 } } },
        y: { grid: { color: 'rgba(128,128,128,.08)' }, ticks: { color: '#888', font: { size: 10 }, callback: v => '$' + Math.round(v) } }
      }
    }
  });
}

function initSentChart() {
  const ctx = document.getElementById('sentChart').getContext('2d');
  if (sentChartInst) sentChartInst.destroy();
  const s = STOCKS[currentTicker];
  sentChartInst = new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: ['Bullish', 'Neutral', 'Bearish'],
      datasets: [{ data: [s.news, 20, 100 - s.news - 20], backgroundColor: ['#639922', '#EF9F27', '#A32D2D'], borderWidth: 0 }]
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: { legend: { display: false }, tooltip: { callbacks: { label: c => `${c.label}: ${c.parsed}%` } } },
      cutout: '65%'
    }
  });
}

function initShapChart() {
  const ctx = document.getElementById('shapChart').getContext('2d');
  if (shapChartInst) shapChartInst.destroy();
  shapChartInst = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: ['RSI 14', 'MACD Signal', 'SMA 50', 'Close Lag1', 'Volume OBV', 'BB Width', 'ATR 14', 'Stoch %K'],
      datasets: [{
        label: 'SHAP Importance',
        data: [0.31, 0.27, 0.21, 0.18, 0.14, 0.11, 0.09, 0.07],
        backgroundColor: ['#378ADD','#378ADD','#5DCAA5','#5DCAA5','#EF9F27','#EF9F27','#D85A30','#D85A30'],
        borderRadius: 3
      }]
    },
    options: {
      indexAxis: 'y', responsive: true, maintainAspectRatio: false,
      plugins: { legend: { display: false }, tooltip: { callbacks: { label: c => `Importance: ${c.parsed.x.toFixed(2)}` } } },
      scales: {
        x: { grid: { color: 'rgba(128,128,128,.08)' }, ticks: { color: '#888', font: { size: 10 }, callback: v => v.toFixed(2) } },
        y: { grid: { display: false }, ticks: { color: '#888', font: { size: 10 } } }
      }
    }
  });
}

function initLossChart() {
  const ctx = document.getElementById('lossChart').getContext('2d');
  if (lossChartInst) lossChartInst.destroy();
  const epochs = Array.from({ length: 100 }, (_, i) => i + 1);
  const train = epochs.map(e => 0.85 * Math.exp(-e * 0.045) + 0.012 + (Math.random() - 0.5) * 0.005);
  const val   = epochs.map(e => 0.92 * Math.exp(-e * 0.038) + 0.018 + (Math.random() - 0.5) * 0.008);
  lossChartInst = new Chart(ctx, {
    type: 'line',
    data: {
      labels: epochs.filter((_, i) => i % 5 === 0),
      datasets: [
        { label: 'Train Loss', data: train.filter((_, i) => i % 5 === 0), borderColor: '#378ADD', backgroundColor: 'transparent', borderWidth: 1.5, pointRadius: 0, tension: 0.4 },
        { label: 'Val Loss',   data: val.filter((_, i) => i % 5 === 0),   borderColor: '#D85A30', backgroundColor: 'transparent', borderWidth: 1.5, borderDash: [4, 2], pointRadius: 0, tension: 0.4 }
      ]
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: {
        x: { grid: { color: 'rgba(128,128,128,.08)' }, ticks: { maxTicksLimit: 6, color: '#888', font: { size: 10 } }, title: { display: true, text: 'Epochs', color: '#888', font: { size: 10 } } },
        y: { grid: { color: 'rgba(128,128,128,.08)' }, ticks: { color: '#888', font: { size: 10 }, callback: v => v.toFixed(3) } }
      }
    }
  });
}

function initHorizonChart() {
  const ctx = document.getElementById('horizonChart').getContext('2d');
  if (horizonChartInst) horizonChartInst.destroy();
  const s = STOCKS[currentTicker];
  const n = 30, start = s.price, drift = (s.pred - s.price) / 5;
  const preds = Array.from({ length: n }, (_, i) =>
    +(start + drift * (i + 1) + (Math.random() - 0.5) * s.price * 0.005).toFixed(2)
  );
  const upper  = preds.map((v, i) => +(v + s.price * 0.008 * (i + 1)).toFixed(2));
  const lower  = preds.map((v, i) => +(v - s.price * 0.008 * (i + 1)).toFixed(2));
  const labels = Array.from({ length: n }, (_, i) => {
    const d = new Date();
    d.setDate(d.getDate() + i + 1);
    return d.toLocaleDateString('en', { month: 'short', day: 'numeric' });
  });
  horizonChartInst = new Chart(ctx, {
    type: 'line',
    data: {
      labels,
      datasets: [
        { label: 'Upper CI', data: upper, borderColor: 'transparent', backgroundColor: 'rgba(55,138,221,0.12)', fill: '+1', pointRadius: 0, tension: 0.4 },
        { label: 'Lower CI', data: lower, borderColor: 'transparent', fill: false, pointRadius: 0 },
        { label: 'Forecast', data: preds, borderColor: s.color, backgroundColor: 'transparent', borderWidth: 2, pointRadius: 2, tension: 0.4, pointBackgroundColor: s.color }
      ]
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: { legend: { display: false }, tooltip: { callbacks: { label: c => `$${c.parsed.y.toFixed(2)}` } } },
      scales: {
        x: { grid: { color: 'rgba(128,128,128,.08)' }, ticks: { maxTicksLimit: 8, color: '#888', font: { size: 10 } } },
        y: { grid: { color: 'rgba(128,128,128,.08)' }, ticks: { color: '#888', font: { size: 10 }, callback: v => '$' + v.toFixed(0) } }
      }
    }
  });
}

// ── Metrics update ────────────────────────────
function updateMetrics() {
  const s    = STOCKS[currentTicker];
  const chg  = s.price - s.price / (1 + 0.0066);
  const pdiff = s.pred - s.price;
  const pct  = (pdiff / s.price * 100).toFixed(1);

  document.getElementById('m-price').textContent   = '$' + s.price.toFixed(2);
  document.getElementById('m-change').textContent  = (chg >= 0 ? '+' : '') + chg.toFixed(2) + ' (' + (chg / s.price * 100).toFixed(2) + '%)';
  document.getElementById('m-change').className    = 'metric-sub ' + (chg >= 0 ? 'up' : 'dn');
  document.getElementById('m-pred').textContent    = '$' + s.pred.toFixed(2);
  document.getElementById('m-pred-chg').textContent = (pdiff >= 0 ? '+' : '') + pdiff.toFixed(2) + ' (' + pct + '%)';
  document.getElementById('m-pred-chg').style.color = pdiff >= 0 ? '#378ADD' : '#E24B4A';
  document.getElementById('m-acc').textContent     = s.acc.toFixed(1) + '%';
  document.getElementById('m-rmse').textContent    = 'RMSE: $' + s.rmse.toFixed(2);
  document.getElementById('m-signal').textContent  = s.signal;
  document.getElementById('m-signal').style.color  = s.signal.includes('BUY') && !s.signal.includes('SELL') ? '#3B6D11' : s.signal === 'SELL' ? '#A32D2D' : '#854F0B';
  document.getElementById('m-conf').textContent    = 'Confidence: ' + s.conf + '%';

  document.getElementById('sig-rsi').textContent   = s.rsi;
  document.getElementById('sig-macd').textContent  = s.macd;
  document.getElementById('sig-sma20').textContent = '$' + s.sma20.toFixed(1);
  document.getElementById('sig-sma50').textContent = '$' + s.sma50.toFixed(1);
  document.getElementById('sig-bb').textContent    = s.bb;
  document.getElementById('sig-obv').textContent   = s.obv;
  document.getElementById('sig-atr').textContent   = s.atr.toFixed(2);

  document.getElementById('pred-display').textContent = '$' + s.pred.toFixed(2) + ' (' + (pdiff >= 0 ? '+' : '') + pct + '%)';
  document.getElementById('pred-display').className   = 'predict-val ' + (pdiff >= 0 ? 'up' : 'dn');

  const arc = Math.round(125.6 * s.conf / 100);
  document.getElementById('conf-arc').setAttribute('stroke-dasharray', arc + ' 126');
  document.getElementById('conf-text').textContent = s.conf + '%';

  document.getElementById('sent-news').textContent   = (s.news >= 60 ? 'Bullish ' : 'Mixed ') + s.news + '%';
  document.getElementById('fill-news').style.width   = s.news + '%';
  document.getElementById('fill-news').style.background = s.news >= 60 ? '#639922' : '#EF9F27';

  document.getElementById('sent-twit').textContent   = (s.twit >= 60 ? 'Positive ' : 'Mixed ') + s.twit + '%';
  document.getElementById('fill-twit').style.width   = s.twit + '%';

  document.getElementById('sent-reddit').textContent = (s.reddit >= 60 ? 'Bullish ' : 'Mixed ') + s.reddit + '%';
  document.getElementById('fill-reddit').style.width = s.reddit + '%';
  document.getElementById('fill-reddit').style.background = s.reddit >= 60 ? '#639922' : '#EF9F27';

  document.getElementById('sent-analyst').textContent = (s.analyst >= 70 ? 'Buy ' : 'Hold ') + s.analyst + '%';
  document.getElementById('fill-analyst').style.width = s.analyst + '%';
  document.getElementById('fill-analyst').style.background = s.analyst >= 70 ? '#639922' : '#EF9F27';

  const feed = document.getElementById('news-feed');
  feed.innerHTML = s.newsItems.map((h, i) =>
    `<div class="news-item">
      <div class="news-time">${[2, 14, 28, 41, '1 hr'][i]} ${i < 4 ? 'min' : 'ago'} ago</div>
      <div class="news-head">${h}</div>
    </div>`
  ).join('');
}

// ── Ticker switch ─────────────────────────────
function setTicker(t, btn) {
  currentTicker = t;
  document.querySelectorAll('.ticker-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  updateMetrics();
  initPriceChart(t);
  initSentChart();
  initHorizonChart();
}

// ── Time range switch ─────────────────────────
function setRange(r, btn) {
  document.querySelectorAll('.seg-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  const nMap = { '1W': 7, '1M': 30, '3M': 90, '1Y': 252 };
  const n = nMap[r] || 90;
  const s = STOCKS[currentTicker];
  const actual = genPriceSeries(s.price * (1 - (n / 252) * 0.15), n, s.price * 0.012);
  actual[n - 1] = s.price;
  const pred = genPredSeries(actual, s.pred - s.price, s.price * 0.012 * 0.5);
  const labels = [];
  for (let i = n - 1; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    labels.push(d.toLocaleDateString('en', { month: 'short', day: 'numeric' }));
  }
  priceChartInst.data.labels = labels;
  priceChartInst.data.datasets[2].data = actual;
  priceChartInst.data.datasets[3].data = pred;
  priceChartInst.data.datasets[0].data = actual.map((v, i) => pred[i] !== null ? pred[i] + s.price * 0.012 * 1.5 * (1 + i * 0.02) : null);
  priceChartInst.data.datasets[1].data = actual.map((v, i) => pred[i] !== null ? pred[i] - s.price * 0.012 * 1.5 * (1 + i * 0.02) : null);
  priceChartInst.update();
}

// ── Live simulation ───────────────────────────
function startLiveUpdates() {
  setInterval(() => {
    Object.keys(STOCKS).forEach(t => {
      STOCKS[t].price = +(STOCKS[t].price * (1 + (Math.random() - 0.499) * 0.0008)).toFixed(2);
    });
    updateMetrics();
    if (priceChartInst && priceData[currentTicker]) {
      const d = priceData[currentTicker];
      d.actual[d.actual.length - 1] = STOCKS[currentTicker].price;
      priceChartInst.data.datasets[2].data = [...d.actual];
      priceChartInst.update('none');
    }
  }, 2000);
}

// ── Clock ─────────────────────────────────────
function startClock() {
  setInterval(() => {
    document.getElementById('clock').textContent =
      new Date().toLocaleTimeString('en', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  }, 1000);
}

// ── Boot ──────────────────────────────────────
window.addEventListener('load', () => {
  initPriceChart(currentTicker);
  initSentChart();
  initShapChart();
  initLossChart();
  initHorizonChart();
  updateMetrics();
  startLiveUpdates();
  startClock();
});
