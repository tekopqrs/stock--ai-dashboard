# StockAI — Prediction Dashboard

A live stock market prediction dashboard with Chart.js visualisations.

## Files

```
stockai-dashboard/
├── index.html   ← main page
├── style.css    ← all styling
├── app.js       ← data, charts, live simulation
└── README.md    ← this file
```

## How to run in VS Code

### Option 1 — Live Server extension (recommended)
1. Install the **Live Server** extension by Ritwick Dey
   - Open Extensions panel (`Ctrl+Shift+X` / `Cmd+Shift+X`)
   - Search "Live Server" → Install
2. Open the `stockai-dashboard` folder in VS Code
3. Right-click `index.html` → **"Open with Live Server"**
4. Dashboard opens at `http://127.0.0.1:5500`

### Option 2 — Open directly in browser
1. Navigate to the folder in Explorer/Finder
2. Double-click `index.html`
3. It opens straight in your default browser

> **Note:** Chart.js is loaded from a CDN, so you need an internet
> connection the first time. After that the browser caches it.

## Features

- **6 tickers** — AAPL, GOOGL, MSFT, TSLA, AMZN, NVDA
- **Live simulation** — prices tick every 2 seconds
- **Price chart** — actual vs predicted with confidence bands (1W / 1M / 3M / 1Y)
- **Technical signals** — RSI, MACD, SMA, Bollinger, OBV, ATR
- **Sentiment analysis** — News, Twitter/X, Reddit, Analyst ratings
- **Model comparison** — LSTM, CNN-LSTM, XGBoost, RF, SVR, ARIMA
- **SHAP feature importance** — horizontal bar chart
- **Loss curve** — training vs validation over 100 epochs
- **30-day horizon** — forecast with widening confidence intervals
- **Responsive** — works on mobile and tablet too
